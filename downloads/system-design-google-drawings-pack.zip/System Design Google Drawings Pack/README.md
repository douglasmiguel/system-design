# System Design Google Drawings Pack

Use the files in **png/** with Google Drawings: choose **Insert → Image → Upload from computer**, then position and connect them with native Google Drawings arrows. Do not drag the ZIP file itself into the canvas—extract it first.

Each component is a compact standard RGB PNG with a white card, an icon, and a name. Google does not import them as editable native shapes.

If Google Drawings rejects a PNG in your browser, use the matching file in **jpeg/**. SVG is deliberately not included because Google Drawings does not support it. The component set mirrors the project's Excalidraw icon sheet.
